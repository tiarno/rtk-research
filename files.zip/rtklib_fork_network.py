"""
RTKLIB fork/supply-chain network analysis
==========================================

Pulls the GitHub fork tree for tomojitakasu/RTKLIB and computes centrality
metrics to find high-leverage disclosure/patch chokepoints — i.e. which
forks, if they never pull an upstream security fix, leave the largest
share of the downstream ecosystem exposed.

Same pipeline shape as the sanctions-evasion / ALPR network analyses:
    extraction (GitHub API) -> cleaning -> graph construction (networkx)
    -> centrality analysis (betweenness / degree)

Requires:
    pip install requests networkx --break-system-packages

Set a GITHUB_TOKEN env var to raise the API rate limit from 60/hr
(unauthenticated) to 5000/hr — with ~1.8k forks plus their sub-forks,
you will hit the unauthenticated limit almost immediately.

Usage:
    export GITHUB_TOKEN=ghp_xxxxxxxx
    python rtklib_fork_network.py
"""
import os
import time
import requests
import networkx as nx

API = "https://api.github.com"
TOKEN = os.environ.get("GITHUB_TOKEN")
HEADERS = {"Accept": "application/vnd.github+json"}
if TOKEN:
    HEADERS["Authorization"] = f"Bearer {TOKEN}"

ROOT_OWNER, ROOT_REPO = "tomojitakasu", "RTKLIB"


def gh_get(url, params=None):
    """GET with basic rate-limit backoff."""
    while True:
        r = requests.get(url, headers=HEADERS, params=params)
        if r.status_code == 403 and "rate limit" in r.text.lower():
            reset = int(r.headers.get("X-RateLimit-Reset", time.time() + 60))
            wait = max(reset - time.time(), 5)
            print(f"  rate limited, sleeping {wait:.0f}s...")
            time.sleep(wait)
            continue
        r.raise_for_status()
        return r


def get_forks(owner, repo, per_page=100):
    """Yield all DIRECT forks of owner/repo (one page at a time)."""
    page = 1
    while True:
        r = gh_get(
            f"{API}/repos/{owner}/{repo}/forks",
            params={"per_page": per_page, "page": page, "sort": "oldest"},
        )
        batch = r.json()
        if not batch:
            return
        yield from batch
        page += 1


def build_fork_graph(owner, repo, max_depth=3):
    """
    BFS through the fork tree.

    GitHub's /forks endpoint only returns an owner/repo's DIRECT forks —
    to capture fork-of-a-fork relationships (which is where most of the
    interesting "who actually built on top of whom" structure lives) we
    recurse into any fork that itself has forks.
    """
    G = nx.DiGraph()
    root_id = f"{owner}/{repo}"
    G.add_node(root_id, stars=None, depth=0, description="upstream (official)")

    frontier = [(owner, repo, 0)]
    seen = {root_id}

    while frontier:
        o, r, depth = frontier.pop(0)
        if depth >= max_depth:
            continue
        node_id = f"{o}/{r}"
        print(f"expanding {node_id} (depth {depth})...")
        for fork in get_forks(o, r):
            fid = fork["full_name"]
            if fid in seen:
                continue
            seen.add(fid)
            G.add_node(
                fid,
                stars=fork.get("stargazers_count", 0),
                pushed_at=fork.get("pushed_at"),
                description=(fork.get("description") or "")[:120],
                depth=depth + 1,
            )
            G.add_edge(node_id, fid, relation="fork_of")
            if fork.get("forks_count", 0) > 0:
                frontier.append((fork["owner"]["login"], fork["name"], depth + 1))

    return G


def analyze(G, top_n=15):
    """Rank nodes by betweenness centrality — the chokepoint metric."""
    betweenness = nx.betweenness_centrality(G.to_undirected())
    out_degree = dict(G.out_degree())  # direct sub-forks per node

    ranked = sorted(
        G.nodes,
        key=lambda n: (betweenness[n], out_degree.get(n, 0)),
        reverse=True,
    )

    print(f"\nTop {top_n} nodes by betweenness centrality (patch chokepoints):")
    print(f"{'repo':45s} {'betweenness':>12s} {'direct forks':>13s} {'stars':>6s}")
    for n in ranked[:top_n]:
        stars = G.nodes[n].get("stars", "?")
        print(f"{n:45s} {betweenness[n]:12.4f} {out_degree.get(n, 0):13d} {str(stars):>6s}")

    return betweenness, out_degree


if __name__ == "__main__":
    print(
        f"Building fork graph for {ROOT_OWNER}/{ROOT_REPO} "
        f"(this can take a while for ~1.8k forks — set GITHUB_TOKEN "
        f"to avoid rate limiting)...\n"
    )
    G = build_fork_graph(ROOT_OWNER, ROOT_REPO, max_depth=3)
    print(f"\nGraph built: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")

    out_path = "rtklib_fork_graph.graphml"
    nx.write_graphml(G, out_path)
    print(f"Saved {out_path} — open in Gephi for visual exploration/layout")

    analyze(G)
